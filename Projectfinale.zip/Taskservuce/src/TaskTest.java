
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    public void testTaskCreation() {
        Task task = new Task("1234567890", "Sample Task", "This is a valid description");
        assertEquals("1234567890", task.getTaskId());
        assertEquals("Sample Task", task.getName());
        assertEquals("This is a valid description", task.getDescription());
    }

    @Test
    public void testTaskIdValidation() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Sample Task", "Valid description");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Sample Task", "Valid description");
        });
    }

    @Test
    public void testNameValidation() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1234567890", null, "Valid description");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1234567890", "This name is way too long for the limit", "Valid description");
        });
    }

    @Test
    public void testDescriptionValidation() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1234567890", "Sample Task", null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1234567890", "Sample Task", "This description is way too long and exceeds fifty characters");
        });
    }
}