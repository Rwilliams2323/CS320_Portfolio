
// TaskService.java
import java.util.HashMap;
import java.util.Map;

public class Taskservice {
    private Map<String, Task> taskMap;

    public Taskservice() {
        taskMap = new HashMap<>();
    }

    public void addTask(Task task) {
        if (taskMap.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("Task ID already exists");
        }
        taskMap.put(task.getTaskId(), task);
    }

    public void deleteTask(String taskId) {
        if (!taskMap.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID does not exist");
        }
        taskMap.remove(taskId);
    }

    public void updateTaskName(String taskId, String newName) {
        Task task = taskMap.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task ID does not exist");
        }
        task.setName(newName);
    }

    public void updateTaskDescription(String taskId, String newDescription) {
        Task task = taskMap.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task ID does not exist");
        }
        task.setDescription(newDescription);
    }

    public Task getTask(String taskId) {
        if (!taskMap.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID does not exist");
        }
        return taskMap.get(taskId);
    }
}