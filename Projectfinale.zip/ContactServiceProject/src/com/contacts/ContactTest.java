package com.contacts;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class ContactTest {

    @Test
    public void testValidContactCreation() {
        Contact contact = new Contact("0123456789", "John", "Doe", "5555555555", "123 Main St");
        assertEquals("0123456789", contact.getContactId());
        assertEquals("John", contact.getFirstName());
        assertEquals("Doe", contact.getLastName());
        assertEquals("5555555555", contact.getPhoneNumber());
        assertEquals("123 Main St", contact.getAddress());
    }

    @Test
    public void testContactFirstNameLongerThan10Characters() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Contact("0123456789", "JohnJohnJohn", "Doe", "5555555555", "123 Main St");
        });

        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            Contact contact = new Contact("0123456789", "John", "Doe", "5555555555", "123 Main St");
            contact.setFirstName("John John John");
        });
    }

    @Test
    public void testContactFirstNameNull() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Contact("0123456789", null, "Doe", "5555555555", "123 Main St");
        });

        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            Contact contact = new Contact("0123456789", "John", "Doe", "5555555555", "123 Main St");
            contact.setFirstName(null);
        });
    }

    // Add other relevant tests as needed
}