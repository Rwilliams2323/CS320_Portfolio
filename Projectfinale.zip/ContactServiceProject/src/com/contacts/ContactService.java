package com.contacts;

import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private Map<String, Contact> contacts = new HashMap<>();

    // Add a contact to the service
    public void addContact(Contact contact) {
        if (contacts.containsKey(contact.getContactId())) {
            throw new IllegalArgumentException("Contact ID already exists");
        }
        contacts.put(contact.getContactId(), contact);
    }

    // Delete a contact by contact ID
    public void deleteContact(String contactID) {
        if (!contacts.containsKey(contactID)) {
            throw new IllegalArgumentException("Contact not found");
        }
        contacts.remove(contactID);
    }

    // Update contact fields by contact ID
    public void updateContact(String contactID, String firstName, String lastName, String phone, String address) {
        Contact contact = contacts.get(contactID);
        if (contact == null) {
            throw new IllegalArgumentException("Contact not found");
        }

        if (firstName != null && firstName.length() <= 10) contact.setFirstName(firstName);
        if (lastName != null && lastName.length() <= 10) contact.setLastName(lastName);
        if (phone != null && phone.length() == 10) contact.setPhoneNumber(phone);
        if (address != null && address.length() <= 30) contact.setAddress(address);
    }

    // Get a contact by contact ID
    public Contact getContact(String contactID) {
        if (!contacts.containsKey(contactID)) {
            throw new IllegalArgumentException("Contact not found");
        }
        return contacts.get(contactID);
    }
}