package com;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Date;

public class AppointmentServiceTest {

    private AppointmentService appointmentService;

    @BeforeEach
    public void setUp() {
        appointmentService = new AppointmentService();
    }

    @Test
    public void testAddAppointment() {
        Appointment appointment = new Appointment("12345", new Date(System.currentTimeMillis() + 86400000), "Consultation");
        appointmentService.addAppointment(appointment);
        assertEquals(appointment, appointmentService.getAppointment("12345"));
    }

    @Test
    public void testAddAppointmentWithDuplicateId() {
        Appointment appointment = new Appointment("12345", new Date(System.currentTimeMillis() + 86400000), "Consultation");
        appointmentService.addAppointment(appointment);
        assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.addAppointment(appointment);
        });
    }

    @Test
    public void testDeleteAppointment() {
        Appointment appointment = new Appointment("12345", new Date(System.currentTimeMillis() + 86400000), "Consultation");
        appointmentService.addAppointment(appointment);
        appointmentService.deleteAppointment("12345");
        assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.getAppointment("12345");
        });
    }

    @Test
    public void testDeleteNonExistentAppointment() {
        assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.deleteAppointment("99999");
        });
    }
}
