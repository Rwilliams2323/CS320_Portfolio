package com;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;

public class AppointmentTest {

    @Test
    public void testValidAppointmentCreation() {
        Appointment appointment = new Appointment("12345", new Date(System.currentTimeMillis() + 86400000), "Checkup");
        assertEquals("12345", appointment.getAppointmentId());
        assertNotNull(appointment.getAppointmentDate());
        assertEquals("Checkup", appointment.getDescription());
    }

    @Test
    public void testAppointmentIdTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", new Date(System.currentTimeMillis() + 86400000), "Valid description");
        });
    }

    @Test
    public void testNullAppointmentDate() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", null, "Valid description");
        });
    }

    @Test
    public void testPastAppointmentDate() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", new Date(System.currentTimeMillis() - 86400000), "Valid description");
        });
    }

    @Test
    public void testDescriptionTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", new Date(System.currentTimeMillis() + 86400000), "This description is way too long and exceeds the 50 characters limit.");
        });
    }
}